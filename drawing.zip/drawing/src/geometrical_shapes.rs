use raster::{Color, Image};
use rand::Rng;

#[derive(Debug, Clone)]
pub struct Point {
    pub x: i32,
    pub y: i32,
}

#[derive(Debug)]
pub struct Line {
    pub one: Point,
    pub two: Point,
}

#[derive(Debug)]
pub struct Rectangle {
    one: Point,
    two: Point,
}

#[derive(Debug)]
pub struct Circle {
    center: Point,
    radius: i32,
}

impl Circle {
    pub fn random(width: i32, height: i32) -> Self {
        let x1: i32 = rand::thread_rng().gen_range(0..width);
        let y1: i32 = rand::thread_rng().gen_range(0..height);
        let radius = rand::thread_rng().gen_range(1..=500);

        Circle {
            center: Point::new(x1, y1),
            radius,
        }

    }
}

impl Drawable for Circle {
    fn draw(&self, image: &mut Image) {

        let mut x = self.radius;
        let mut y = 0;
        let mut err = 0;
        let color = Color::rgb(
            rand::thread_rng().gen_range(0..=255),
            rand::thread_rng().gen_range(0..=255),
            rand::thread_rng().gen_range(0..=255),
        );
        
        while x >= y {

            image.display(self.center.x + x, self.center.y + y, color.clone());
            image.display(self.center.x + y, self.center.y + x, color.clone());
            image.display(self.center.x - y, self.center.y + x, color.clone());
            image.display(self.center.x - x, self.center.y + y, color.clone());
            image.display(self.center.x - x, self.center.y - y, color.clone());
            image.display(self.center.x - y, self.center.y - x, color.clone());
            image.display(self.center.x + y, self.center.y - x, color.clone());
            image.display(self.center.x + x, self.center.y - y, color.clone());

            if err <= 0 {
            y += 1;
            err += 2 * y + 1;
            }
            if err > 0 {
                x -= 1;
                err -= 2 * x + 1;
            }
        }
    }
}

impl Rectangle {
    pub fn new(a: &Point, b: &Point) -> Self {
        Rectangle { one: a.clone(), two: b.clone()}
    }
}

pub trait Drawable {
    fn draw(&self, _image: &mut Image);
}

impl Point {
    pub fn random(width: i32, height: i32) -> Self {
        let x1: i32 = rand::thread_rng().gen_range(0..width);
        let y1: i32 = rand::thread_rng().gen_range(0..height);
        Self {
            x: x1,
            y: y1,
        }
    }
    pub fn new(x1: i32, y1: i32) -> Self {
        Self { x: x1, y: y1 }
    }
}

pub trait Displayable {
    fn display(&mut self, x: i32, y: i32, color: Color);
}

impl Drawable for Point {
    fn draw(&self, image: &mut Image) {
        let _ = image.set_pixel(self.x, self.y, Color::white());
    }
}

impl Drawable for Rectangle {
    fn draw(&self,  image: &mut Image) {
        let x1 = self.one.x.min(self.two.x);  
        let y1 = self.one.y.min(self.two.y);  
        let x2 = self.one.x.max(self.two.x);  
        let y2 = self.one.y.max(self.two.y) * 2;  
        
        for x in x1..=x2 {
            let _ = image.set_pixel(x, y1, Color::white());
            let _ = image.set_pixel(x, y2, Color::white());
        }
        
        for y in y1..=y2 {
            let _ = image.set_pixel(x1, y, Color::white());
            let _ = image.set_pixel(x2, y, Color::white());
        }
    }
}

impl Line {
    pub fn random(width: i32, height: i32) -> Self {

        let x1 = rand::thread_rng().gen_range(0..width);
        let y1 = rand::thread_rng().gen_range(0..height);

        let x2 = rand::thread_rng().gen_range(0..width);
        let y2 = rand::thread_rng().gen_range(0..height);

        Line {
            one: Point{x: x1, y: x2},
            two: Point{x: y1, y: y2},
        }
    }
}

impl Drawable for Line {
    fn draw(&self, image: &mut Image) {
        let mut x0 = self.one.x;
        let mut y0 = self.one.y;

        let x1 = self.two.x;
        let y1 = self.two.y;

        let dx = (x1 - x0).abs();
        let dy = -(y1 - y0).abs();
        let sx = if x0 < x1 { 1 } else { -1 };
        let sy = if y0 < y1 { 1 } else { -1 };
        let mut err = dx + dy;

        loop {

            let _ = image.set_pixel(x0, y0, Color::white());
            

            if x0 == x1 && y0 == y1 {
                break;
            }

            let e2 = 2 * err;
            if e2 >= dy {
                err += dy;
                x0 += sx;
            }
            if e2 <= dx {
                err += dx;
                y0 += sy;
            }
        }
    }
}
